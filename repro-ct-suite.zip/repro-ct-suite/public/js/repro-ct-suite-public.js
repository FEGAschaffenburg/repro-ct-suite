/**
 * Public-facing JavaScript for the plugin.
 *
 * @package Repro_CT_Suite
 */

(function( $ ) {
	'use strict';

	$(function() {
		// Public JavaScript code here
		console.log('Repro CT-Suite Public loaded');
	});

})( jQuery );
